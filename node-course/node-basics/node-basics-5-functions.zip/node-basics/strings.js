var firstName = 'Andrew';
var lastName = 'Mead';
var fullName = firstName + ' ' + lastName;

console.log(fullName);
console.log(fullName.length);