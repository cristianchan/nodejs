var name = 'Julie';

if (name === 'Mike' || name === 'Jen') {
	console.log('Hello friend!');
} else if (name === 'Chet') {
	console.log('Hey');
} else {
	console.log('Hey stranger!');
}