var pet = {
	name: 'Patches',
	type: 'Dog'
};

function printPet (pet) {
	console.log('Your ' + pet.type + ' is named ' + pet.name);
}

printPet(pet);