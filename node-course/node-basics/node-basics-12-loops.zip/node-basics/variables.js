var name = 'Andrew';
console.log(name);