var testOne = 100;
var testTwo = 80;
var testThree = 90;
var averageGrade = (testOne + testTwo + testThree) / 3;

console.log('Your average grade is: ' + averageGrade);