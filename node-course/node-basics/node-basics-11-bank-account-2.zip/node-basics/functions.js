function add (a, b) {
	var result = a + b;

	return result;
}

var result = add(1, 88);
console.log(result);

console.log(add(3, 2));